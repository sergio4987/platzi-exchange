<template>
  <div>
    <px-assets-table />
  </div>
</template>

<script>
import PxAssetsTable from "@/components/PxAssetsTable";

export default {
  name: "Home",
  components: { PxAssetsTable }
};
</script>